import statistics
FOLDER = "swimdata/"
import hfpy_utils
CHARTS = "charts/"

def read_swim_data(filename):
    #process swimmer's details from each file and return the values
    swimmer, age, distance, stroke = filename.removesuffix(".txt").split("-")
    
    with open(FOLDER + filename) as file:
        lines = file.readlines()
        times = lines[0].strip().split(",")

    converts = []
    for t in times:
        if ":" in t:
            minutes, rest = t.split(":")
            seconds, hundredths = rest.split(".")
        else:
            minutes = 0
            seconds, hundredths = t.split(".")
        converts.append((int(minutes)*60*100) + (int(seconds)*100) + (int(hundredths)))

    average = statistics.mean(converts)
    min_secs, hundredths = f"{(average/100):.2f}".split('.')
    minutes = int(min_secs) // 60
    seconds = int(min_secs) - (minutes*60)
    average = f"{minutes}:{seconds:0>2}.{hundredths}"

    return swimmer, age, distance, stroke, times, average, converts

def produce_bar_chart(fn, location=CHARTS):
    """Given the name of a swimmer's file, produce a HTML/SVG-based bar chart.

    Save the chart to the CHARTS folder. Return the path to the bar chart file.
    """
    swimmer, age, distance, stroke, times, average, converts = read_swim_data(fn)
    from_max = max(converts)
    times.reverse()
    converts.reverse()
    title = f"{swimmer} (under {age}) {distance} {stroke}"
    header = f"""
    <!DOCTYPE html>
        <html>
            <head>
                <title> {title} </title>
                <link rel="stylesheet" href="static/webapp.css"/>
            </head>
            <body>
                <h3> {title} </h3>
        """
    body = ""
    for n, t in enumerate(times):
        bar_width = hfpy_utils.convert2range(converts[n], 0, from_max, 0, 350)
        body = body + f"""
                <svg height="30" width="400">
                <rect height="30" width="{bar_width}" style="fill:rgb(0,0,255);" />
                </svg>{t}<br />
        """
    footer = f"""
                <p>{average}</p>
            </body>
        </html>
        """
    page = header + body + footer
    save_to = f"{location}{fn.removesuffix('.txt')}.html"
    with open(save_to, "w") as ft:
        print(page, file=ft)

    return save_to



